# FreeForm

FreeForm is a small browser-based game prototype with a home hub, a character test, an avatar preview, and two playable mini-games.

## Run it

The project uses browser JavaScript modules and Three.js from a CDN, so run it through a local web server instead of opening the HTML files directly.

1. Extract the ZIP.
2. Open a terminal in the extracted `FreeForm-main` folder.
3. Run `python -m http.server 8000`.
4. Open `http://localhost:8000` in a modern browser.

Internet access is needed to load Three.js on `Character.html` and `latency.html`. The new 2D mini-games run without a game engine dependency.

## Pages

- `index.html` — FreeForm home hub and navigation.
- `murderMysteryRoom.html` — original mystery mini-game: find three clues, avoid the culprit, and accuse one of three suspects.
- `swordFightRoom.html` — arena mini-game: move, swing your tag wand, and tag five bots.
- `Character.html` — 3D character movement and camera test.
- `latency.html` — two-view simulated latency demo.
- `skinCustomization.html` — body, head, and leg color preview.
- `profile.html` — local profile and score summary.
- `auth.html` — browser-local prototype sign-up/sign-in.

## Controls

**Character test / Latency Lab**
- `W A S D`: move.
- Mouse drag: orbit camera.
- Mouse wheel: zoom.
- `Space`: jump (where supported).

**Mystery Room**
- `W A S D` or arrow keys: move.
- `E`: collect a nearby clue.
- `1`, `2`, or `3`: accuse the corresponding suspect after finding all three clues.
- Use the on-screen controls on touch devices.

**Tag Arena**
- `W A S D` or arrow keys: move.
- `Space`: tag nearby bots.
- Use the on-screen controls on touch devices.

## Accounts, profile, and leaderboard limitations

The sign-up/sign-in page uses the Web Crypto API to hash passwords before saving a prototype account record in `localStorage`. The active username, avatar colors, and scores are also stored in the current browser only. This is **not server-backed authentication**: accounts do not sync across browsers or devices, browser storage can be cleared or modified, and local scores are not a global/anti-cheat leaderboard. Do not use a real or reused password with this prototype. Real multi-user accounts require a trusted authentication backend and database.

## Face asset

`assets/default-face.svg` is the original FreeForm default face used in the character demos and avatar preview.

## Tests

Run the lightweight static checks with:

```sh
node tests/smoke-test.mjs
```

These checks verify expected pages, asset references, controls, and major feature hooks. They do not replace testing the games in a real browser.
