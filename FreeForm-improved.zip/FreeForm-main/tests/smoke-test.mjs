import assert from 'node:assert/strict';
import { readFileSync, existsSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const read = (p) => readFileSync(join(root, p), 'utf8');
const requiredFiles = [
  'index.html', 'auth.html', 'profile.html', 'skinCustomization.html',
  'murderMysteryRoom.html', 'swordFightRoom.html', 'Character.html',
  'latency.html', 'assets/freeform.css', 'assets/freeform.js',
  'assets/default-face.svg'
];
for (const file of requiredFiles) assert.ok(existsSync(join(root, file)), `Missing ${file}`);

const index = read('index.html');
for (const link of ['murderMysteryRoom.html', 'swordFightRoom.html', 'skinCustomization.html', 'profile.html']) {
  assert.ok(index.includes(link), `Home page must link to ${link}`);
}
const auth = read('auth.html');
for (const feature of ['PBKDF2', 'KEYS.accounts', 'KEYS.session', 'confirm-password']) {
  assert.ok(auth.includes(feature), `Auth is missing ${feature}`);
}
const mystery = read('murderMysteryRoom.html');
for (const feature of ['cluesFound', 'function accuse', 'health', 'getLeaderboard', 'requestAnimationFrame']) {
  assert.ok(mystery.includes(feature), `Mystery game is missing ${feature}`);
}
const arena = read('swordFightRoom.html');
for (const feature of ['function attack', 'health', 'getLeaderboard', 'requestAnimationFrame', 'data-key']) {
  assert.ok(arena.includes(feature), `Arena game is missing ${feature}`);
}
for (const file of ['Character.html', 'latency.html']) {
  const html = read(file);
  assert.ok(html.includes('assets/default-face.svg'), `${file} should load the face asset`);
  assert.ok(html.includes('FreeForm.getSession()'), `${file} should use the local username`);
}
assert.ok(read('skinCustomization.html').includes('FreeForm.saveAvatar'));
assert.ok(read('profile.html').includes('FreeForm.getScores'));
console.log(`FreeForm smoke checks passed (${requiredFiles.length} required files).`);
